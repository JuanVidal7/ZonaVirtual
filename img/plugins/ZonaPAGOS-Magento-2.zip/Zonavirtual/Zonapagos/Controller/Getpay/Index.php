<?php

namespace Zonavirtual\Zonapagos\Controller\Getpay;

use Magento\Checkout\Model\Type\Onepage;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Framework\DataObject;
use Magento\Framework\Registry;
use Magento\Payment\Model\IframeConfigProvider;
use Magento\Quote\Api\CartManagementInterface;

class Index extends \Magento\Checkout\Controller\Onepage {

    const ZONAPAGOS_VERIFICAR_LIVE = 'https://www.zonapagos.com/api_verificar_pagoV3/api/verificar_pago_v3';

    /**
     * Order success action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function getConfig($config_path) {
        return $this->scopeConfig->getValue(
                        $config_path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * verificar pago
     * */
    public function pendingPayments($order_id) {

        $service_url = self::ZONAPAGOS_VERIFICAR_LIVE;

        $curl = curl_init($service_url);
        $curl_post_data = array(
            'str_id_pago' => $order_id,
            'int_id_tienda' => $this->getConfig('payment/zonapagos/id_unico'),
            'str_id_clave' => $this->getConfig('payment/zonapagos/clave')
        );
        $data_string = json_encode($curl_post_data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string)
        ));
        $curl_response = curl_exec($curl);
        if ($curl_response === false) {
            $info = curl_getinfo($curl);
            curl_close($curl);
            die('error occured during curl exec. Additioanl info: ' . var_export($info));
        }
        curl_close($curl);

        $json_result = json_decode($curl_response, true);

        return $json_result;
    }

    public function execute() {
        // Pending orders
        $message = '';
        $estado_pago = $this->getRequest()->getParam('estado_pago');
        $nombre_banco = ucfirst(strtolower($this->getRequest()->getParam('nombre_banco')));
        $valor_pagado = $this->getRequest()->getParam('valor_pagado');
        $codigo_transaccion = $this->getRequest()->getParam('codigo_transaccion');
        $detalle_estado = ucfirst(strtolower($this->getRequest()->getParam('detalle_estado')));
        $order_id = $this->getRequest()->getParam('id_pago');

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create('\Magento\Sales\Model\Order')->load($order_id);

        $json_result = $this->pendingPayments($order_id);

        $result = $json_result['Contador_Pagos'];
        $resultp = $json_result['res_pagos_v3'];
        $resultp = $resultp[0];
        $error = $json_result['int_error'];
        $message = $message . '<p>' . $order->getData('increment_id') . '-' . $result . '</p>';

        if ($result >= 1 && $error == 0) {
            $order->setData("zp_banco",$nombre_banco);
            $order->setData("zp_cus",$codigo_transaccion);
            $order->setData("zp_id_pago",$resultp['str_id_pago']);
            $order->setData("zp_fecha",$resultp['dat_fecha']);
            $order->setData("zp_vr_pagado",$valor_pagado);
            $order->setData("zp_franquicia",$resultp['str_franquicia']);

            switch ($estado_pago) {
                case 1: //Asentar pago Exitoso
                    $order->setData("zp_detalle_estado",'Aprobada');
                    $order->setState("complete")->setStatus("complete");
                    break;

                case 888: //Pago Pendiente por Iniciar

                case 999:   //Pago Pendiente por Finalizar
                    $order->setData("zp_detalle_estado",'Pendiente');
                    $order->setState("pending")->setStatus("pending");
                    break;

                case 1000:   //Pago rechazado

                case 1001:   //Pago rechazado
                    $order->setData("zp_detalle_estado",'Rechazada');
                    $order->setState("canceled")->setStatus("canceled");
                    break;
                default:
                    $order->setData("zp_detalle_estado",'Pendiente');
                    $order->setState("pending")->setStatus("pending");
                    break;
            }
        } else if ($result == 0 || $error == 1) {
            $order->setData("zp_detalle_estado",'Rechazada');
            $order->setData("zp_banco",$nombre_banco);
            $order->setData("zp_cus",$codigo_transaccion);
            $order->setData("zp_id_pago",$resultp['str_id_pago']);
            $order->setData("zp_fecha",$resultp['dat_fecha']);
            $order->setData("zp_vr_pagado",$valor_pagado);
            $order->setData("zp_franquicia",$resultp['str_franquicia']);
            $order->setState("canceled")->setStatus("canceled");
        } else {
            $order->setData("zp_detalle_estado",'Rechazada');
            $order->setData("zp_banco",$nombre_banco);
            $order->setData("zp_cus",$codigo_transaccion);
            $order->setData("zp_id_pago",$resultp['str_id_pago']);
            $order->setData("zp_fecha",$resultp['dat_fecha']);
            $order->setData("zp_vr_pagado",$valor_pagado);
            $order->setData("zp_franquicia",$resultp['str_franquicia']);
            $message = "HUBO UN ERROR, NO SE ASENTO EL PAGO.  "
                    . "<br/> JSON enviado: " . $curl_post_data . " "
                    . "<br/>JSON recibido:" . $curl_response;
        }
        $order->save();
        print $message;
    }

}

?>
