<?php

namespace Zonavirtual\Zonapagos\Controller\Index;

use Magento\Checkout\Model\Type\Onepage;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Response\Http;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Framework\DataObject;
use Magento\Framework\Registry;
use Magento\Payment\Model\IframeConfigProvider;
use Magento\Quote\Api\CartManagementInterface;

class Index extends \Magento\Checkout\Controller\Onepage {

    const ZONAPAGOS_VERIFICAR_LIVE = 'https://www.zonapagos.com/api_verificar_pagoV3/api/verificar_pago_v3';
    const ZONAPAGOS_INICIAR_LIVE = 'https://www.zonapagos.com/api_inicio_pago/api/inicio_pagoV2';

    /**
     * Order success action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function getConfig($config_path) {
        return $this->scopeConfig->getValue(
                        $config_path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function cus($order_id) {

        $service_url = self::ZONAPAGOS_VERIFICAR_LIVE;
        $curl = curl_init($service_url);
        $curl_post_data = array(
            'str_id_pago' => $order_id,
            'int_id_tienda' => $this->getConfig('payment/zonapagos/id_unico'),
            'str_id_clave' => $this->getConfig('payment/zonapagos/clave')
        );
        $data_string = json_encode($curl_post_data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string)
        ));
        $curl_response = curl_exec($curl);
        if ($curl_response === false) {
            $info = curl_getinfo($curl);
            curl_close($curl);
            die('error occured during curl exec. Additioanl info: ' . var_export($info));
        }
        curl_close($curl);

        $json_result = json_decode($curl_response, true);

        $pagos = $json_result['Contador_Pagos'];
        $error = $json_result['int_error'];
        $cus = "";
        if ($pagos >= 1 && $error == 0) {
            $resultp = $json_result['res_pagos_v3'];
            $resultp = $resultp[0];
            $cus = $resultp['str_codigo_Transacción'];
        }
        return $cus;
    }

    /**
     * verificar pago
     * */
    public function pendingPayments($order_id) {

        $service_url = self::ZONAPAGOS_VERIFICAR_LIVE;

        $curl = curl_init($service_url);
        $curl_post_data = array(
            'str_id_pago' => $order_id,
            'int_id_tienda' => $this->getConfig('payment/zonapagos/id_unico'),
            'str_id_clave' => $this->getConfig('payment/zonapagos/clave')
        );
        $data_string = json_encode($curl_post_data);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string)
        ));
        $curl_response = curl_exec($curl);
        if ($curl_response === false) {
            $info = curl_getinfo($curl);
            curl_close($curl);
            die('error occured during curl exec. Additioanl info: ' . var_export($info));
        }
        curl_close($curl);

        $json_result = json_decode($curl_response, true);

        $pagos = $json_result['Contador_Pagos'];
        if ($pagos) {
            $result = 1;
        } else {
            $result = 0;
        }
        return $result;
    }

    public function get_zonapagos_args($order) {
        $order_id = $order->getData('increment_id');
        $billingAddress = $order->getBillingAddress();
        //Zonapagos Args
        $zonapagos_args = array(
            'id_tienda' => $this->getConfig('payment/zonapagos/id_unico'),
            'clave' => $this->getConfig('payment/zonapagos/clave'),
            'total_con_iva' => $order->getGrandTotal(),
            'valor_iva' => $order->getBaseTaxAmount(),
            'id_pago' => $order_id,
            'descripcion_pago' => 'Pago orden # ' . $order_id,
            // informacion del cliente
            'email' => $billingAddress->getData('email'),
            'id_cliente' => ($billingAddress->getData('customer_id') != '' ? $billingAddress->getData('customer_id') : 'Invitado'),
            'tipo_id' => '7',
            'nombre_cliente' => $billingAddress->getData('firstname'),
            'apellido_cliente' => $billingAddress->getData('lastname'),
            'telefono_cliente' => $billingAddress->getData('telephone'),
            'info_opcional1' => '',
            'info_opcional2' => '',
            'info_opcional3' => '',
            // tipo servicio en la pasarela
            'codigo_servicio_principal' => $this->getConfig('payment/zonapagos/cod_servicio'),
            'lista_codigos_servicio_multicredito' => null,
            'lista_nit_codigos_servicio_multicredito' => null,
            'lista_valores_con_iva' => null,
            'lista_valores_iva' => null,
            'total_codigos_servicio' => '0'
        );
        return $zonapagos_args;
    }

    public function execute() {
        $session = $this->getOnepage()->getCheckout();
        if (!$this->_objectManager->get('Magento\Checkout\Model\Session\SuccessValidator')->isValid()) {
            return $this->resultRedirectFactory->create()->setPath('checkout/cart');
        }
        $customerEmail = $session->getQuote()->getShippingAddress()->getEmail();
        $session->clearQuote();
        $resultPage = $this->resultPageFactory->create();

        $order_id = $session->getLastOrderId();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $order = $objectManager->create('\Magento\Sales\Model\Order')->load($order_id);
        $resource = $objectManager->create('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        $sales_order_table = $resource->getTableName('sales_order');
        $sales_order_address_table = $resource->getTableName('sales_order_address');
        $sales_order_payment_table = $resource->getTableName('sales_order_payment');

        // Pending orders
        $sql = "SELECT o.entity_id 
		FROM " . $sales_order_table . " o 
		LEFT JOIN " . $sales_order_address_table . " oa ON oa.parent_id = o.entity_id
		LEFT JOIN " . $sales_order_payment_table . " op ON op.parent_id = o.entity_id
		WHERE 
		o.status = 'pending' AND
		o.entity_id <> " . $order_id . " AND
		op.method = 'zonapagos' AND
		oa.address_type = 'billing' AND
		oa.email = (SELECT email FROM " . $sales_order_address_table . " WHERE address_type = 'billing' AND parent_id = " . $order_id . ")
		ORDER BY o.entity_id ASC LIMIT 1";

        $result = $connection->fetchAll($sql);
        
        if ($result) {
            $pendingOrder = $result[0]['entity_id'];
            $cus = $this->cus($pendingOrder);
            if ($cus == '')
                $cus = 'No disponible';
            $message = '<p><span style="color: #ff0b0b;">En este momento su orden No. ' . $pendingOrder . ' presenta un proceso de pago cuya transacci&oacute;n se encuentra PENDIENTE de recibir confirmaci&oacute;n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci&oacute;n sobre el estado actual de su operaci&oacute;n puede comunicarse a nuestras l&iacute;neas de atenci&oacute;n al cliente ' . $this->getConfig('payment/zonapagos/phone') . ' o enviar un correo electr&oacute;nico a ' . $this->getConfig('payment/zonapagos/email') . ' y preguntar por el estado de la transacci&oacute;n: ' . $cus . '.</span></p>';
            $order->setState("canceled")->setStatus("canceled");
        } else {
            $message = 'No hay pendientes';
            $pendingPayments = $this->pendingPayments($order_id);
            if (!$pendingPayments) {
                $service_url = self::ZONAPAGOS_INICIAR_LIVE;

                $curl = curl_init($service_url);
                $curl_post_data = $this->get_zonapagos_args($order);
                $data_string = json_encode($curl_post_data);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
                curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string)
                ));
                $curl_response = curl_exec($curl);
                if ($curl_response === false) {
                    $info = curl_getinfo($curl);
                    curl_close($curl);
                    die('error occured during curl exec. Additioanl info: ' . var_export($info));
                }
                curl_close($curl);

                $result = json_decode($curl_response, true);
                $url = 'https://www.zonapagos.com/' . $this->getConfig('payment/zonapagos/t_ruta') . '/pago.asp?estado_pago=iniciar_pago&identificador=' . $result;
                $order->setState("pending")->setStatus("pending");
                $order->save();
                header('Location:' . $url);
                die();
            } else {
                $cus = $this->cus($order_id);
                if ($cus == '')
                    $cus = 'No disponible';
                $message = '<p><span style="color: #ff0b0b;">En este momento su orden No. ' . $order_id . ' presenta un proceso de pago cuya transacci&oacute;n se encuentra PENDIENTE de recibir confirmaci&oacute;n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci&oacute;n sobre el estado actual de su operaci&oacute;n puede comunicarse a nuestras l&iacute;neas de atenci&oacute;n al cliente ' . $this->getConfig('payment/zonapagos/phone') . ' o enviar un correo electr&oacute;nico a ' . $this->getConfig('payment/zonapagos/email') . ' y preguntar por el estado de la transacci&oacute;n: ' . $cus . '.</span></p>';
                $order->setState("canceled")->setStatus("canceled");
            }
        }
        $order->save();
        $resultPage->getConfig()->getTitle()->set(__('Zonapagos'));
        $resultPage->getLayout()->getBlock('zonapagos')->setMessage($message);
        return $resultPage;
    }

}

?>
