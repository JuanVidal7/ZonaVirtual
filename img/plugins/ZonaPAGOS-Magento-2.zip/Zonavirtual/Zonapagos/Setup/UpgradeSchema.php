<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Zonavirtual\Zonapagos\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

/**
 * @codeCoverageIgnore
 */

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrades DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $orderTable = 'sales_order';

        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_banco',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Banco Zonapagos'
                ]
            );
        
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_detalle_estado',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Detalle de estado'
                ]
            );
            
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_cus',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Codigo unico'
                ]
            );
        
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_id_pago',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Id del pago'
                ]
            );
        
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_fecha',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Fecha de pago'
                ]
            );
        
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_vr_pagado',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Valor pagado'
                ]
            );
        
        $setup->getConnection()
            ->addColumn(
                $setup->getTable($orderTable),
                'zp_franquicia',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'comment' =>'Franquicia'
                ]
            );

        $setup->endSetup();
    }
}
