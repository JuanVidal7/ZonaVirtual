<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Zonavirtual\Zonapagos\Model;

/**
 * Zonapagos payment method model
 *
 * @method \Magento\Quote\Api\Data\PaymentMethodExtensionInterface getExtensionAttributes()
 */
class Zonapagos extends \Magento\Payment\Model\Method\AbstractMethod
{
    const PAYMENT_METHOD_ZONAPAGOS_CODE = 'zonapagos';

    /**
     * Payment method code
     *
     * @var string
     */
    protected $_code = self::PAYMENT_METHOD_ZONAPAGOS_CODE;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_isGateway = false;

    /**
     * Get variables from config
     *
     * @return string
     */
    public function getMessage()
    {
        return trim($this->getConfigData('message'));
    }
    
    public function getT_ruta()
    {
        return trim($this->getConfigData('t_ruta'));
    }
    
    public function getId_unico()
    {
        return trim($this->getConfigData('id_unico'));
    }
    
    public function getCod_servicio()
    {
        return trim($this->getConfigData('cod_servicio'));
    }
    
    public function getClave()
    {
        return trim($this->getConfigData('clave'));
    }
    
    public function getEmail()
    {
        return trim($this->getConfigData('email'));
    }
    
    public function getPhone()
    {
        return trim($this->getConfigData('phone'));
    }
    
}
