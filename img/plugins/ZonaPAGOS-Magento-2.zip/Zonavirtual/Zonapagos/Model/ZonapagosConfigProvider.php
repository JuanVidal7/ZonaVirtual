<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Zonavirtual\Zonapagos\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Helper\Data as PaymentHelper;

class ZonapagosConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string[]
     */
    protected $methodCode = Zonapagos::PAYMENT_METHOD_ZONAPAGOS_CODE;

    /**
     * @var Checkmo
     */
    protected $method;

    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @param PaymentHelper $paymentHelper
     * @param Escaper $escaper
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        Escaper $escaper
    ) {
        $this->escaper = $escaper;
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        return $this->method->isAvailable() ? [
            'payment' => [
                'zonapagos' => [
                    'message' => $this->getMessage(),
                    't_ruta' => $this->getT_ruta(),
                    'id_unico' => $this->getId_unico(),
                    'cod_servicio' => $this->getCod_servicio(),
                    'clave' => $this->getClave(),
                    'email' => $this->getEmail(),
                    'phone' => $this->getPhone(),
                ],
            ],
        ] : [];
    }

    /**
     * Get variables from config
     *
     * @return string
     */
    protected function getMessage()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getMessage()));
    }
    
    protected function getT_ruta()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getT_ruta()));
    }
    
    protected function getId_unico()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getId_unico()));
    }
    
    protected function getCod_servicio()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getCod_servicio()));
    }
    
    protected function getClave()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getClave()));
    }
    
    protected function getEmail()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getEmail()));
    }
    
    protected function getPhone()
    {
        return nl2br($this->escaper->escapeHtml($this->method->getPhone()));
    }
    
}
