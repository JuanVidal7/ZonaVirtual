<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require( dirname(__DIR__) . '/../../wp-config.php' );
global $wpdb;
global $woocommerce;
$woocommerce = new woocommerce();
$available_gateways = $woocommerce->payment_gateways->get_available_payment_gateways();
$registros = $wpdb->get_results($wpdb->prepare("SELECT p.ID FROM $wpdb->posts p LEFT JOIN $wpdb->postmeta m ON m.post_id = p.ID WHERE m.meta_key = '_payment_method' AND m.meta_value = 'zonapagos' AND p.post_status = %s AND post_date < DATE_SUB(NOW(),INTERVAL 7 MINUTE)", 'wc-pending'));

for ($i = 0; $i < count($registros); $i++) {
    $id_pago = $registros[$i]->ID;
    $order = new WC_Order($id_pago);
    $periodo_sonda = 600;
    $tipo_pago = get_post_meta($id_pago, '_zp_id_forma_pago');
    $tiempo = 0;
    if ($tipo_pago[0] == "42")
        $periodo_sonda = 3600;
    $ultima_consulta = get_post_meta($id_pago, '_zp_ultima_consulta');
    if (sizeof($ultima_consulta) > 0)
        $tiempo = $ultima_consulta[0];
    if (time() > $tiempo + $periodo_sonda) {
        $service_url = 'https://www.zonapagos.com/WsVerificarPagoV4/VerificarPagos.asmx?wsdl';
        $client = new SoapClient($service_url);
        $params = array(
            'int_id_comercio' => $available_gateways['zonapagos']->settings['int_id_comercio'],
            'str_usr_comercio' => $available_gateways['zonapagos']->settings['str_usr_comercio'],
            'str_pwd_Comercio' => $available_gateways['zonapagos']->settings['str_pwd_Comercio'],
            'str_id_pago' => $id_pago,
            'int_no_pago' => -1,
            'int_error' => 0,
            'int_cantidad_pagos' => 0
        );
        $result = $client->__soapCall('verificar_pago_v4', array($params));
        update_post_meta($id_pago, '_zp_ultima_consulta', time());
        if ($result->verificar_pago_v4Result == 1) {
            $pagos = $result->int_cantidad_pagos;
            $transacciones = explode("| ; |", $result->str_res_pago);
            $transacciones_array = [];
            foreach ($transacciones as $transaccion) {
                $transaccion_array = explode(" | ", $transaccion);
                if (sizeof($transaccion_array) > 1)
                    array_push($transacciones_array, $transaccion_array);
            }

            foreach ($transacciones_array as $transaccion) {
                $estado_pago = $transaccion[1];
                switch ($estado_pago) {
                    case "1":
                        $order->payment_complete();
                        $order->update_status('completed', __('Pago exitoso', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago exitoso');
                        break;
                    case "888":
                        $order->update_status('pending', __('Pago pendiente por iniciar', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago pendiente por iniciar');
                        break;
                    case "999":
                        $order->update_status('pending', __('Pago pendiente por finalizar', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago pendiente por finalizar');
                        break;
                    case "4001":
                        $order->update_status('pending', __('Pago pendiente por CR', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago pendiente por CR');
                        break;
                    case "1000":
                        $order->set_status('cancelled', __('Pago rechazado', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago rechazado');
                        break;
                    case "1001":
                        $order->update_status('cancelled', __('Pago rechazado. Error entre PSE y la Entidad Bancaria', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago rechazado. Error entre PSE y la Entidad Bancaria');
                        break;
                    case "4000":
                        $order->update_status('cancelled', __('Pago rechazado CR', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago rechazado CR');
                        break;
                    case "4003":
                        $order->update_status('cancelled', __('Pago rechazado. Error CR', 'woothemes'));
                        update_post_meta($id_pago, '_zp_detalle_estado', 'Pago rechazado. Error CR');
                        break;
                }
                $order->save();
                $forma_pago = $transaccion[14];
                switch ($forma_pago) {
                    case "29":
                        update_post_meta($id_pago, '_zp_id_forma_pago', '29');
                        update_post_meta($id_pago, '_zp_forma_pago', 'PSE');
                        update_post_meta($id_pago, '_zp_ticketID', $transaccion[15]);
                        update_post_meta($id_pago, '_zp_codigo_servico', $transaccion[16]);
                        update_post_meta($id_pago, '_zp_codigo_banco', $transaccion[17]);
                        update_post_meta($id_pago, '_zp_nombre_banco', $transaccion[18]);
                        update_post_meta($id_pago, '_zp_codigo_transaccion', $transaccion[19]);
                        update_post_meta($id_pago, '_zp_ciclo_transaccion', $transaccion[20]);
                        break;
                    case "32":
                        update_post_meta($id_pago, '_zp_id_forma_pago', '32');
                        update_post_meta($id_pago, '_zp_forma_pago', 'Tarjeta de crédito');
                        update_post_meta($id_pago, '_zp_ticketID', $transaccion[15]);
                        update_post_meta($id_pago, '_zp_num_tarjeta', $transaccion[16]);
                        update_post_meta($id_pago, '_zp_franquicia', $transaccion[17]);
                        update_post_meta($id_pago, '_zp_cod_aprobacion', $transaccion[18]);
                        update_post_meta($id_pago, '_zp_num_recibo', $transaccion[19]);
                        break;
                    case "41":
                        update_post_meta($id_pago, '_zp_id_forma_pago', '41');
                        update_post_meta($id_pago, '_zp_forma_pago', 'PDF generado en ZonaPAGOS');
                        break;
                    case "42":
                        update_post_meta($id_pago, '_zp_id_forma_pago', '42');
                        update_post_meta($id_pago, '_zp_forma_pago', 'Gana');
                        break;
                    case "45":
                        update_post_meta($id_pago, '_zp_id_forma_pago', '45');
                        update_post_meta($id_pago, '_zp_forma_pago', 'Tarjeta Tuya');
                        break;
                }
            }
        } else {
            echo "Error:" . $result->str_detalle;
        }
    }
}
?>
