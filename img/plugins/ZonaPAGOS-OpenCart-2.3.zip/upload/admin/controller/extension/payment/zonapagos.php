<?php
class ControllerExtensionPaymentZonapagos extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/zonapagos');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('zonapagos', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_all_zones'] = $this->language->get('text_all_zones');

		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_t_ruta'] = $this->language->get('entry_t_ruta');
		$data['entry_id_unico'] = $this->language->get('entry_id_unico');
		$data['entry_cod_servicio'] = $this->language->get('entry_cod_servicio');
		$data['entry_clave'] = $this->language->get('entry_clave');
		$data['entry_email'] = $this->language->get('entry_email');
		$data['entry_phone'] = $this->language->get('entry_phone');
		
		$data['help_total'] = $this->language->get('help_total');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['t_ruta'])) {
			$data['error_t_ruta'] = $this->error['t_ruta'];
		} else {
			$data['error_t_ruta'] = '';
		}
		
		if (isset($this->error['id_unico'])) {
			$data['error_id_unico'] = $this->error['id_unico'];
		} else {
			$data['error_id_unico'] = '';
		}
		
		if (isset($this->error['cod_servicio'])) {
			$data['error_cod_servicio'] = $this->error['cod_servicio'];
		} else {
			$data['error_cod_servicio'] = '';
		}
		
		if (isset($this->error['clave'])) {
			$data['error_clave'] = $this->error['clave'];
		} else {
			$data['error_clave'] = '';
		}
		
		if (isset($this->error['email'])) {
			$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}
		
		if (isset($this->error['phone'])) {
			$data['error_phone'] = $this->error['phone'];
		} else {
			$data['error_phone'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/zonapagos', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/zonapagos', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);

		if (isset($this->request->post['zonapagos_status'])) {
			$data['zonapagos_status'] = $this->request->post['zonapagos_status'];
		} else {
			$data['zonapagos_status'] = $this->config->get('zonapagos_status');
		}
		
		if (isset($this->request->post['zonapagos_t_ruta'])) {
			$data['zonapagos_t_ruta'] = $this->request->post['zonapagos_t_ruta'];
		} else {
			$data['zonapagos_t_ruta'] = $this->config->get('zonapagos_t_ruta');
		}
		
		if (isset($this->request->post['zonapagos_id_unico'])) {
			$data['zonapagos_id_unico'] = $this->request->post['zonapagos_id_unico'];
		} else {
			$data['zonapagos_id_unico'] = $this->config->get('zonapagos_id_unico');
		}
		
		if (isset($this->request->post['zonapagos_cod_servicio'])) {
			$data['zonapagos_cod_servicio'] = $this->request->post['zonapagos_cod_servicio'];
		} else {
			$data['zonapagos_cod_servicio'] = $this->config->get('zonapagos_cod_servicio');
		}
		
		if (isset($this->request->post['zonapagos_clave'])) {
			$data['zonapagos_clave'] = $this->request->post['zonapagos_clave'];
		} else {
			$data['zonapagos_clave'] = $this->config->get('zonapagos_clave');
		}
		
		if (isset($this->request->post['zonapagos_email'])) {
			$data['zonapagos_email'] = $this->request->post['zonapagos_email'];
		} else {
			$data['zonapagos_email'] = $this->config->get('zonapagos_email');
		}
		
		if (isset($this->request->post['zonapagos_phone'])) {
			$data['zonapagos_phone'] = $this->request->post['zonapagos_phone'];
		} else {
			$data['zonapagos_phone'] = $this->config->get('zonapagos_phone');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/zonapagos', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/zonapagos')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['zonapagos_t_ruta']) {
			$this->error['t_ruta'] = $this->language->get('error_t_ruta');
		}
		
		if (!$this->request->post['zonapagos_id_unico']) {
			$this->error['id_unico'] = $this->language->get('error_id_unico');
		}
		
		if (!$this->request->post['zonapagos_cod_servicio']) {
			$this->error['cod_servicio'] = $this->language->get('error_cod_servicio');
		}
		
		if (!$this->request->post['zonapagos_clave']) {
			$this->error['clave'] = $this->language->get('error_clave');
		}
		
		if (!$this->request->post['zonapagos_email']) {
			$this->error['email'] = $this->language->get('error_email');
		}
		
		if (!$this->request->post['zonapagos_phone']) {
			$this->error['phone'] = $this->language->get('error_phone');
		}

		return !$this->error;
	}
}
