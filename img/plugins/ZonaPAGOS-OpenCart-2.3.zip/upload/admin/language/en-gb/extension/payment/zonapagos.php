<?php
// Heading
$_['heading_title']		 = 'Zonapagos';

// Text
$_['text_extension']		 = 'Extensions';
$_['text_success']		 = 'Success: You have modified zonapagos account details!';
$_['text_edit']                  = 'Edit Zonapagos';
$_['text_zonapagos']		 = '<a href="http://www.zonavirtual.com" target="_blank"><img src="view/image/payment/zonapagos.png" alt="Zonapagos - Zonavirtual" title="Zonapagos - Zonavirtual" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_status']		 = 'Estado';
$_['entry_t_ruta']		 = 'Ruta';
$_['entry_id_unico']		 = 'ID único de la tienda';
$_['entry_cod_servicio']	 = 'Código de servicio de la tienda';
$_['entry_clave']		 = 'Clave de la tienda';
$_['entry_email']		 = 'Email de la tienda';
$_['entry_phone']		 = 'Teléfono de la tienda';

// Help
$_['help_total']		 = 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']	     = 'Warning: You do not have permission to modify payment zonapagos!';
$_['error_t_ruta']	     = 'La ruta es obligatoria!';
$_['error_id_unico']	     = 'El ID único es obligatorio!';
$_['error_cod_servicio']     = 'El código de servicio es obligatorio!';
$_['error_clave']	     = 'La clave es obligatoria!';
$_['error_email']	     = 'El email es obligatorio!';
$_['error_phone']	     = 'El teléfono es obligatorio!';
