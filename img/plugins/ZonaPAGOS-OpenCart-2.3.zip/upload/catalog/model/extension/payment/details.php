<?php
class ModelExtensionPaymentDetails extends Model {
	public function addDetails($data) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "zonapagos_details` SET order_id = '" . (int)$data['order_id'] . "', zp_banco = '" . $this->db->escape($data['zp_banco']) . "', zp_cus = '" . $this->db->escape($data['zp_cus']) . "', zp_fecha = '" . $this->db->escape($data['zp_fecha']) . "', zp_vr_pagado = '" . $this->db->escape($data['zp_vr_pagado']) . "', zp_franquicia = '" . $this->db->escape($data['zp_franquicia']) . "', zp_detalle_estado = '" . $this->db->escape($data['zp_detalle_estado']) . "'");

		$detail_id = $this->db->getLastId();
		return $detail_id;
	}
	
	public function editDetails($data) {
		$this->db->query("UPDATE `" . DB_PREFIX . "zonapagos_details` SET zp_banco = '" . $this->db->escape($data['zp_banco']) . "', zp_cus = '" . $this->db->escape($data['zp_cus']) . "', zp_fecha = '" . $this->db->escape($data['zp_fecha']) . "', zp_vr_pagado = '" . $this->db->escape($data['zp_vr_pagado']) . "', zp_franquicia = '" . $this->db->escape($data['zp_franquicia']) . "', zp_detalle_estado = '" . $this->db->escape($data['zp_detalle_estado']) . "' WHERE order_id = '" . (int)$data['order_id'] . "'");

		$detail_id = $this->db->getLastId();
		return $detail_id;
	}

	public function getDetails($order_id) {
		$detail_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zonapagos_details` WHERE order_id = '" . (int)$order_id . "'");

		if ($detail_query->num_rows) {
			return array(
				'zp_banco'                => $detail_query->row['zp_banco'],
				'zp_cus'              	  => $detail_query->row['zp_cus'],
				'zp_fecha'          	  => $detail_query->row['zp_fecha'],
				'zp_vr_pagado'            => $detail_query->row['zp_vr_pagado'],
				'zp_franquicia'           => $detail_query->row['zp_franquicia'],
				'zp_detalle_estado'       => $detail_query->row['zp_detalle_estado']
			);
		} else {
			return false;
		}
	}
	
	public function getPendingOrders() {
		$pending_orders = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order` WHERE payment_code = 'zonapagos' AND order_status_id = 1 AND date_added < DATE_SUB(NOW(),INTERVAL 7 MINUTE)");

		if ($pending_orders->num_rows) {
			return $pending_orders->rows;
		} else {
			return false;
		}
	}
}
