<?php
class ControllerExtensionPaymentGetpay extends Controller {
	public function index() {
		$this->load->model('setting/setting');
		$this->load->model('checkout/order');
		$this->load->model('extension/payment/details');
		
		$id_pago = $this->request->get['?id_pago'];
		$order = $this->model_checkout_order->getOrder($id_pago);
		
		$body = print_r($_REQUEST, true);
        	$file = $id_pago . '_' . time() . '_' . 'log.txt';
        	//file_put_contents($file, $body);

		$estado_pago = $this->request->get['estado_pago'];
		$nombre_banco = ucfirst(strtolower($this->request->get['nombre_banco']));
		$valor_pagado = $this->request->get['valor_pagado'];
		$codigo_transaccion = $this->request->get['codigo_transaccion'];
		$detalle_estado = ucfirst(strtolower($this->request->get['detalle_estado']));

		$service_url = 'https://www.zonapagos.com/api_verificar_pagoV3/api/verificar_pago_v3';
		$curl = curl_init($service_url);
		$curl_post_data = array(
		    'str_id_pago' => $id_pago,
		    'int_id_tienda' => $this->config->get('zonapagos_id_unico'),
		    'str_id_clave' => $this->config->get('zonapagos_clave')
		);
		$data_string = json_encode($curl_post_data);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		//curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array(
		    'Content-Type: application/json',
		    'Content-Length: ' . strlen($data_string)
		));
		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
		    $info = curl_getinfo($curl);
		    curl_close($curl);
		    die('error occured during curl exec. Additioanl info: ' . var_export($info));
		}
		curl_close($curl);

		$json_result = json_decode($curl_response, true);

		$result = $json_result['Contador_Pagos'];
		$error = $json_result['int_error'];

		if ($estado_pago >= 1) {
		    $resultp = $json_result['res_pagos_v3'];
		    $resultp = $resultp[0];
		    $data['zp_banco'] = $nombre_banco;
		    $data['zp_cus'] = $codigo_transaccion;
		    $data['order_id'] = $id_pago;
		    $data['zp_fecha'] = $resultp['dat_fecha'];
		    $data['zp_vr_pagado'] = $valor_pagado;
		    $data['zp_franquicia'] = $resultp['str_franquicia'];
		    $data['zp_detalle_estado'] = $detalle_estado;
		    if($this->model_extension_payment_details->getDetails($id_pago)){
		    	$this->model_extension_payment_details->editDetails($data);
		    } else {
		    	$this->model_extension_payment_details->addDetails($data);
		    }
		    //$estado_pago = $resultp['int_estado_pago'];

		    if ($estado_pago == 1) {
			$this->model_checkout_order->addOrderHistory($id_pago, 5, '', true);
		    } elseif ($estado_pago == 999 || $estado_pago == 888) {
			$this->model_checkout_order->addOrderHistory($id_pago, 1, '', true);
		    } elseif ($estado_pago == 1000 || $estado_pago == 1001) {
			$this->model_checkout_order->addOrderHistory($id_pago, 7, '', true);
		    }
		} elseif (($result == 0 && $error == 1) || $estado_pago == 0) {
		    $this->model_checkout_order->addOrderHistory($id_pago, 7, '', true);
		    $data['zp_banco'] = $nombre_banco;
		    $data['zp_cus'] = $codigo_transaccion;
		    $data['order_id'] = $id_pago;
		    $data['zp_vr_pagado'] = $valor_pagado;
		    $data['zp_detalle_estado'] = $detalle_estado;
		    if($this->model_extension_payment_details->getDetails($id_pago)){
		    	$this->model_extension_payment_details->editDetails($data);
		    } else {
		    	$this->model_extension_payment_details->addDetails($data);
		    }
		} else {
		    $this->model_checkout_order->addOrderHistory($id_pago, 1, '', true);
		    $data['zp_banco'] = $nombre_banco;
		    $data['zp_cus'] = $codigo_transaccion;
		    $data['order_id'] = $id_pago;
		    $data['zp_vr_pagado'] = $valor_pagado;
		    $data['zp_detalle_estado'] = $detalle_estado;
		    if($this->model_extension_payment_details->getDetails($id_pago)){
		    	$this->model_extension_payment_details->editDetails($data);
		    } else {
		    	$this->model_extension_payment_details->addDetails($data);
		    }
		    echo "HUBO UN ERROR, NO SE ASENTO EL PAGO Y SIGUE PENDIENTE.  "
		    . "<br/> JSON enviado: " . $curl_post_data . " "
		    . "<br/>JSON recibido:" . $curl_response;
		}
	}
}
