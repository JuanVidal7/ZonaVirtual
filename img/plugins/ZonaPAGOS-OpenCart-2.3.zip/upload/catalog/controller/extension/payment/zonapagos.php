<?php
class ControllerExtensionPaymentZonapagos extends Controller {
	const ZONAPAGOS_VERIFICAR_LIVE = 'https://www.zonapagos.com/api_verificar_pagoV3/api/verificar_pago_v3';
	const ZONAPAGOS_INICIAR_LIVE = 'https://www.zonapagos.com/api_inicio_pago/api/inicio_pagoV2';
	
	public function index() {
		$this->load->language('extension/payment/zonapagos');

		$data['text_instruction'] = $this->language->get('text_instruction');
		$data['text_redirect'] = $this->language->get('text_redirect');
		$data['text_loading'] = $this->language->get('text_loading');

		$data['button_confirm'] = $this->language->get('button_confirm');

		$data['continue'] = $this->url->link('extension/payment/zonapagos/confirm');

		return $this->load->view('extension/payment/zonapagos', $data);
	}

	public function confirm() {
		if (isset($this->session->data['identificador'])) {
			$result = $this->session->data['identificador'];
			unset($this->session->data['identificador']);
			$url = 'https://www.zonapagos.com/' . $this->config->get('zonapagos_t_ruta') . '/pago.asp?estado_pago=iniciar_pago&identificador=' . $result;
			header("Location: $url");
			exit;
		}
		if ($this->session->data['payment_method']['code'] == 'zonapagos') {
			$this->load->language('extension/payment/zonapagos');

			$this->load->model('checkout/order');
			$this->load->model('setting/setting');

			$order = $this->model_checkout_order->getOrder($this->session->data['order_id']);
			
			$query = $this->db->query("SELECT order_id FROM " . DB_PREFIX . "order WHERE order_status_id = 1 AND payment_code = 'zonapagos' AND customer_id = " . $order['customer_id'] . " AND order_id <> " . $order['order_id'] . ";");
			if($query->num_rows == 0 || $order['customer_id'] == 0){
				$pago_ok = $this->pago_ok($order);
				if ($pago_ok) {
				    $service_url = self::ZONAPAGOS_INICIAR_LIVE;

				    $curl = curl_init($service_url);
				    $curl_post_data = $this->get_zonapagos_args($order);
				    $data_string = json_encode($curl_post_data);
				    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
				    //curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
				    curl_setopt($curl, CURLOPT_POST, true);
				    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
				    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
				        'Content-Type: application/json',
				        'Content-Length: ' . strlen($data_string)
				    ));
				    $curl_response = curl_exec($curl);
				    if ($curl_response === false) {
				        $info = curl_getinfo($curl);
				        curl_close($curl);
				        die('error occured during curl exec in process_payment. Additioanl info: ' . var_export($info) . 'Curl error: ' . curl_error($curl) . 'Curl exists: ' . function_exists('curl_version'));
				    }
				    curl_close($curl);

				    $result = json_decode($curl_response, true);
				    $this->session->data['identificador'] = $result;
				    $result = 'https://www.zonapagos.com/' . $this->config->get('zonapagos_t_ruta') . '/pago.asp?estado_pago=iniciar_pago&identificador=' . $result;
				    $sec = "0";
				    $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], 1, '', true);
				    $this->cart->clear();
 				    $this->redirect(HTTPS_SERVER . 'index.php?route=extension/payment/zonapagos/confirm');
 				    exit;
				} else {
				    $cus = $this->cus($order['order_id']);
				    $this->session->data['error'] = '<p><span style="color: #ff0b0b;">“En este momento su orden No. ' . $order['order_id'] . ' presenta un proceso de pago cuya transacci&oacute;n se encuentra PENDIENTE de recibir confirmaci&oacute;n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci&oacute;n sobre el estado actual de su operaci&oacute;n puede comunicarse a nuestras l&iacute;neas de atenci&oacute;n al cliente ' . $this->config->get('zonapagos_phone') . ' o enviar un correo electr&oacute;nico a ' . $this->config->get('zonapagos_email') . ' y preguntar por el estado de la transacci&oacute;n: ' . $cus . '"</span></p>';          
				    $sec = "0";
 				    header("Refresh: $sec; url=index.php?refresh=0&route=checkout/checkout");
 				    exit;
				}
			} else {
				$cus = $this->cus($query->rows[0]['order_id']);
				if ($cus == '')
				    $cus = 'No disponible';
				$this->session->data['error'] = '<p><span style="color: #ff0b0b;">“En este momento su orden No. ' . $query->rows[0]['order_id'] . ' presenta un proceso de pago cuya transacci&oacute;n se encuentra PENDIENTE de recibir confirmaci&oacute;n por parte de su entidad financiera, por favor espere unos minutos y vuelva a consultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor informaci&oacute;n sobre el estado actual de su operaci&oacute;n puede comunicarse a nuestras l&iacute;neas de atenci&oacute;n al cliente ' . $this->config->get('zonapagos_phone') . ' o enviar un correo electr&oacute;nico a ' . $this->config->get('zonapagos_email') . ' y preguntar por el estado de la transacci&oacute;n: ' . $cus . '"</span></p>';
				$sec = "0";
 				header("Refresh: $sec; url=index.php?refresh=0&route=checkout/checkout");
 				exit;
			}
		}
	}
	
	function get_zonapagos_args($order) {
            //Zonapagos Arg
            $order_id = $order['order_id'];
            $zonapagos_args = array(
                'id_tienda' => $this->config->get('zonapagos_id_unico'),
                'clave' => $this->config->get('zonapagos_clave'),
                'total_con_iva' => round($order['total'],0),
                'valor_iva' => array_sum($this->cart->getTaxes()),
                'id_pago' => $order_id,
                'descripcion_pago' => 'Pago orden # ' . $order_id,
                // informacion del cliente
                'email' => $order['email'],
                'id_cliente' => $order['customer_id'],
                'tipo_id' => '7',
                'nombre_cliente' => $order['firstname'],
                'apellido_cliente' => $order['lastname'],
                'telefono_cliente' => $order['telephone'],
                'info_opcional1' => '',
                'info_opcional2' => '',
                'info_opcional3' => '',
                // tipo servicio en la pasarela
                'codigo_servicio_principal' => (string)$this->config->get('zonapagos_cod_servicio'),
                'lista_codigos_servicio_multicredito' => null,
                'lista_nit_codigos_servicio_multicredito' => null,
                'lista_valores_con_iva' => null,
                'lista_valores_iva' => null,
                'total_codigos_servicio' => '0'
            );

            return $zonapagos_args;
        }

        /**
         * verificar pago
         * */
        function pago_ok($order) {
            $service_url = self::ZONAPAGOS_VERIFICAR_LIVE;
	    $order_id = $order['order_id'];
            $curl = curl_init($service_url);
            $curl_post_data = array(
                'str_id_pago' => $order_id,
                'int_id_tienda' => $this->config->get('zonapagos_id_unico'),
                'str_id_clave' => $this->config->get('zonapagos_clave')
            );
            $data_string = json_encode($curl_post_data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_string)
            ));
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                die('error occured during curl exec in pago_ok. Additioanl info: ' . var_export($info) . 'Curl error: ' . curl_error($curl) . 'Curl exists: ' . function_exists('curl_version'));
            }
            curl_close($curl);

            $json_result = json_decode($curl_response, true);

            $pagos = $json_result['Contador_Pagos'];
            if ($pagos) {
                $result = 0;
            } else {
                $result = 1;
            }
            return $result;
        }

        function cus($order_id) {
            $service_url = self::ZONAPAGOS_VERIFICAR_LIVE;

            $curl = curl_init($service_url);
            $curl_post_data = array(
                'str_id_pago' => $order_id,
                'int_id_tienda' => $this->config->get('zonapagos_id_unico'),
                'str_id_clave' => $this->config->get('zonapagos_clave')
            );
            $data_string = json_encode($curl_post_data);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            //curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($data_string)
            ));
            $curl_response = curl_exec($curl);
            if ($curl_response === false) {
                $info = curl_getinfo($curl);
                curl_close($curl);
                die('error occured during curl exec in cus. Additioanl info: ' . var_export($info) . 'Curl error: ' . curl_error($curl) . 'Curl exists: ' . function_exists('curl_version'));
            }
            curl_close($curl);

            $json_result = json_decode($curl_response, true);

            $pagos = $json_result['Contador_Pagos'];
            $error = $json_result['int_error'];
            $cus = "";
            if ($pagos >= 1 && $error == 0) {
                $resultp = $json_result['res_pagos_v3'];
                $resultp = $resultp[0];
                $cus = $resultp['str_codigo_transaccion'];
            }
            return $cus;
        }
}
