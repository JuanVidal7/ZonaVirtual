<?php
class ControllerExtensionPaymentSonda extends Controller {
	public function index() {
		$this->load->model('setting/setting');
		$this->load->model('checkout/order');
		$this->load->model('extension/payment/details');
		
		$pending_orders = $this->model_extension_payment_details->getPendingOrders();
		if($pending_orders){
			foreach ($pending_orders as $pending_order) {
				$order_id = $pending_order['order_id'];

				$service_url = 'https://www.zonapagos.com/api_verificar_pagoV3/api/verificar_pago_v3';
				$curl = curl_init($service_url);
				$curl_post_data = array(
				    'str_id_pago' => $order_id,
				    'int_id_tienda' => $this->config->get('zonapagos_id_unico'),
				    'str_id_clave' => $this->config->get('zonapagos_clave')
				);
				$data_string = json_encode($curl_post_data);
				curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
				//curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($curl, CURLOPT_POST, true);
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
				curl_setopt($curl, CURLOPT_HTTPHEADER, array(
				    'Content-Type: application/json',
				    'Content-Length: ' . strlen($data_string)
				));
				$curl_response = curl_exec($curl);
				if ($curl_response === false) {
				    $info = curl_getinfo($curl);
				    curl_close($curl);
				    die('error occured during curl exec. Additioanl info: ' . var_export($info));
				}
				curl_close($curl);

				$json_result = json_decode($curl_response, true);

				$result = $json_result['Contador_Pagos'];
				$error = $json_result['int_error'];
				$resultp = $json_result['res_pagos_v3'];
				$resultp = $resultp[0];

				if ($result >= 1 && $error == 0) {
				    $estado_pago = $resultp['int_estado_pago'];
				    $data['zp_banco'] = $resultp['str_nombre_banco'];
				    $data['zp_cus'] = $resultp['str_codigo_transaccion'];
				    $data['order_id'] = $order_id;
				    $data['zp_fecha'] = $resultp['dat_fecha'];
				    $data['zp_vr_pagado'] = $resultp['dbl_valor_pagado'];
				    $data['zp_franquicia'] = $resultp['str_franquicia'];
				    

				    if ($estado_pago == 1) {
				    	$data['zp_detalle_estado'] = 'Aprobada';
					$this->model_checkout_order->addOrderHistory($order_id, 5, '', true);
				    } elseif ($estado_pago == 999 || $estado_pago == 888) {
				    	$data['zp_detalle_estado'] = 'Pendiente';
					$this->model_checkout_order->addOrderHistory($order_id, 1, '', true);
				    } elseif ($estado_pago == 1000 || $estado_pago == 1001) {
				    	$data['zp_detalle_estado'] = 'Rechazada';
					$this->model_checkout_order->addOrderHistory($order_id, 7, '', true);
				    } else {
				    	$data['zp_detalle_estado'] = 'Pendiente';
					$this->model_checkout_order->addOrderHistory($order_id, 1, '', true);
				    }
				    if($this->model_extension_payment_details->getDetails($order_id)){
				    	$this->model_extension_payment_details->editDetails($data);
				    } else {
				    	$this->model_extension_payment_details->addDetails($data);
				    }
				} elseif ($result == 0 || $error == 1) {
				    $this->model_checkout_order->addOrderHistory($order_id, 7, '', true);
				    $data['zp_banco'] = $resultp['str_nombre_banco'];
				    $data['zp_cus'] = $resultp['str_codigo_transaccion'];
				    $data['order_id'] = $order_id;
				    $data['zp_fecha'] = $resultp['dat_fecha'];
				    $data['zp_vr_pagado'] = $resultp['dbl_valor_pagado'];
				    $data['zp_franquicia'] = $resultp['str_franquicia'];
				    $data['zp_detalle_estado'] = 'Rechazada';
				    if($this->model_extension_payment_details->getDetails($order_id)){
				    	$this->model_extension_payment_details->editDetails($data);
				    } else {
				    	$this->model_extension_payment_details->addDetails($data);
				    }
				} else {
				    $this->model_checkout_order->addOrderHistory($order_id, 1, '', true);
				    $data['zp_banco'] = $resultp['str_nombre_banco'];
				    $data['zp_cus'] = $resultp['str_codigo_transaccion'];
				    $data['order_id'] = $order_id;
				    $data['zp_fecha'] = $resultp['dat_fecha'];
				    $data['zp_vr_pagado'] = $resultp['dbl_valor_pagado'];
				    $data['zp_franquicia'] = $resultp['str_franquicia'];
				    $data['zp_detalle_estado'] = 'Pendiente';
				    if($this->model_extension_payment_details->getDetails($order_id)){
				    	$this->model_extension_payment_details->editDetails($data);
				    } else {
				    	$this->model_extension_payment_details->addDetails($data);
				    }
				    echo "HUBO UN ERROR, NO SE ASENTO EL PAGO Y SIGUE PENDIENTE.  "
				    . "<br/> JSON enviado: " . $curl_post_data . " "
				    . "<br/>JSON recibido:" . $curl_response;
				}
			}
		}
	}
}
