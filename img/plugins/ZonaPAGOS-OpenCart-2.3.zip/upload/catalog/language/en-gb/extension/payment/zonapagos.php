<?php
// Text
$_['text_title']				= '<img src="catalog/view/theme/default/image/zonapagos.png" alt="Zonapagos - Zonavirtual" title="Zonapagos - Zonavirtual" />ZonaPagos - Pagos seguros con tarjetas débito (PSE) y tarjetas de crédito.';
$_['text_instruction']			= 'Zonapagos';
$_['text_redirect']				= 'Por favor revise su orden. Al hacer clic en Confirmar Orden, usted será redirigido a la pasarela de pagos ZonaPAGOS de ZonaVirtual.';
