-- --------------------------------------------------------

--
-- Table structure for table `oc_zonapagos_details`
--

CREATE TABLE `oc_zonapagos_details` (
  `zonapagos_details_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `zp_banco` varchar(255) NOT NULL,
  `zp_cus` varchar(255) NOT NULL,
  `zp_fecha` datetime NOT NULL,
  `zp_vr_pagado` varchar(255) NOT NULL,
  `zp_franquicia` varchar(255) NOT NULL,
  `zp_detalle_estado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oc_zonapagos_details`
--
ALTER TABLE `oc_zonapagos_details`
  ADD PRIMARY KEY (`zonapagos_details_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oc_zonapagos_details`
--
ALTER TABLE `oc_zonapagos_details`
  MODIFY `zonapagos_details_id` int(11) NOT NULL AUTO_INCREMENT;
