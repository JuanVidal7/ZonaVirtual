<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
chdir('../../../../');
define('DRUPAL_ROOT', getcwd());
require_once (getcwd() . '/includes/bootstrap.inc');
require_once ('modules/pm/libraries/nusoap/nusoap.php');
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

$rule = rules_config_load('commerce_payment_zonapagos_pm');
foreach ($rule->actions() as $action) {
  $settings[] = $action->settings['payment_method']['settings'];
}

date_default_timezone_set("America/Bogota");
$now = time();

$id_tienda = $settings[0]['store_code'];
$clave_tienda = $settings[0]['password'];
$result = db_query_range('SELECT o.order_number FROM {commerce_order} o WHERE o.status = :status AND o.data LIKE \'%zonapagos%\' AND ' . $now . ' > o.changed + 420' ,0,20,array(':status' => 'Pending'))->fetchAll();	
foreach($result as $item) {
	$order_id = $item->order_number;
	$order = commerce_order_load($order_id);
	$client = new nusoap_client('http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl', 'wsdl', '', '', '','');	
	$params = array_merge( array (    		
		'str_id_pago' => $order_id,
		'int_id_tienda' => $id_tienda,
		'str_id_clave' => $clave_tienda)
	) ;
	$resultp = $client->call('verificar_pago_v3', $params);
		
	$resultp_est = (int)$resultp['res_pagos_v3']['pagos_v3']['int_estado_pago'];
	if($resultp_est == '1' ){
		$order = commerce_order_status_update($order, 'completed');
		commerce_order_save($order);
		rules_invoke_all(COMMERCE_PAYMENT_STATUS_SUCCESS, $order);
	} else {
		$order = commerce_order_status_update($order, 'canceled');
		commerce_order_save($order);
		rules_invoke_all(COMMERCE_PAYMENT_STATUS_FAILURE, $order);
	}
}
?>
