<?php
$path = $_SERVER['DOCUMENT_ROOT'];
chdir($path."/drupal-7.27");
define('DRUPAL_ROOT', getcwd()); //the most important line
require_once '../../../../includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

error_reporting(E_ALL);
ini_set('display_errors', '1');
/**
 * @file
 * Implements Zonapagos Website Payments Standard in Drupal Commerce checkout.
 */


/**
 * Implements hook_commerce_payment_method_info().
 */
 $result = db_query_range('SELECT o.order_number FROM {commerce_order} o WHERE o.status = :status' ,0,20,array(':status' => 'Pending'))->fetchField();
 echo 'Result:' . $result;
function commerce_zonapagos_pm_commerce_payment_method_info() {
  $payment_methods = array();

  $payment_methods['zonapagos_pm'] = array(
    'base' => 'commerce_zonapagos_pm',
    'title' => t('Zonapagos PM'),
    'short_title' => t('Zonapagos'),
    'description' => t('Zonapagos Website Payments Standard'),
    'terminal' => FALSE,
    'offsite' => TRUE,
    'offsite_autoredirect' => TRUE,

    // Because the order form generation code does not have access to a payment
    // method info array, we set the bn directly there instead of making use of
    // this buttonsource variable. It's here for consistency with other payment
    // methods in this package.
    'buttonsource' => 'CommerceGuys_Cart_PPS',
  );

  return $payment_methods;
}

/**
 * Returns the default settings for the Zonapagos PM payment method.
 */
function commerce_zonapagos_pm_default_settings() {
  $default_currency = commerce_default_currency();

  return array(
    'zp_pending' => '',
    'currency_code' => in_array($default_currency, array_keys(commerce_zonapagos_currencies('zonapagos_pm'))) ? $default_currency : 'USD',
    'allow_supported_currencies' => FALSE,
    'language' => 'US',
    'server' => 'sandbox',
    'payment_action' => 'sale',
    'ipn_logging' => 'notification',
    'receiver_emails' => '',
    'ipn_create_billing_profile' => FALSE,
    'show_payment_instructions' => FALSE,
  );
}

/**
 * Payment method callback: settings form.
 */
function commerce_zonapagos_pm_settings_form($settings = array()) {
  $form = array();

  // Merge default settings into the stored settings array.
  $settings = (array) $settings + commerce_zonapagos_pm_default_settings();

  $form['path'] = array(
    '#type' => 'textfield',
    '#title' => t('Ruta'),
    '#description' => t('La ruta para la URL a la plataforma Zonapagos.'),
    '#default_value' => $settings['path'],
    '#required' => FALSE,
  );
  $form['password'] = array(
    '#type' => 'textfield',
    '#title' => t('Password'),
    '#description' => t('Password del comercio.'),
    '#default_value' => $settings['password'],
    '#required' => TRUE,
  );
  $form['store_code'] = array(
    '#type' => 'textfield',
    '#title' => t('Código del comercio'),
    '#description' => t('Código que identifica el comercio.'),
    '#default_value' => $settings['store_code'],
    '#required' => TRUE,
  );
  $form['master_code'] = array(
    '#type' => 'textfield',
    '#title' => t('Codigo maestro'),
    '#description' => t('Código maestro.'),
    '#default_value' => $settings['master_code'],
    '#required' => TRUE,
  );
  $form['support_phone'] = array(
    '#type' => 'textfield',
    '#title' => t('Teléfono de soporte'),
    '#description' => t('Teléfono del comercio para consultar sobre un pago.'),
    '#default_value' => $settings['support_phone'],
    '#required' => TRUE,
  );
  $form['support_email'] = array(
    '#type' => 'textfield',
    '#title' => t('Email de soporte'),
    '#description' => t('Email del comercio para consultar sobre un pago.'),
    '#default_value' => $settings['support_email'],
    '#required' => TRUE,
  );

  return $form;
}

/**
 * Payment method callback: adds a message to the submission form if enabled in
 * the payment method settings.
 */
function commerce_zonapagos_pm_submit_form($payment_method, $pane_values, $checkout_pane, $order) {
  $form = array();
  $support_phone = $payment_method['settings']['support_phone'];
  $support_email = $payment_method['settings']['support_email'];
  $result = db_query_range('SELECT o.order_number FROM {commerce_order} o WHERE o.status = :status AND o.uid = :uid' ,0,20,
                          array(':status' => 'Pending',':uid' => $order->uid))->fetchField();
  $message = '';
  if ($result) {
    $message = "Lo sentimos pero en estos momento tiene la orden No. " . $result . " en proceso de pago.  Por favor vuelva a intentarlo mas tarde o póngase en contacto con nosotros a través de la línea de atención " . $support_phone . " o envíe sus inquietudes al correo electrónico " . $support_email . " y pregunte por el estado de la transacci&oacute;n.";
  }
  drupal_set_message(t($message), 'error');
  $cus = check_order($order,$payment_method['settings']['store_code'],$payment_method['settings']['password']);
  if($cus != '') {
    $message = 'En este momento su pago No.:' . $order->order_number . ' presenta un proceso de pago cuya transacción se encuentra PENDIENTE de recibir confirmación por parte de su entidad financiera, por favor espere unos minutos y vuelva a cosultar mas tarde para verificar si su pago fue confirmado de forma exitosa. Si desea mayor información sobre el estado actual de su operación puede comunicarse a nuestra línea de atención ' . $support_phone . ' o envíe sus inquietudes al correo electrónico ' . $support_email . ' y pregunte por el estado de la transacción. Identificación de pago: ' . $cus;
    drupal_set_message(t($message), 'error');
  }
  if (!empty($payment_method['settings']['show_payment_instructions'])) {
    $form['zonapagos_pm_information'] = array(
      '#markup' => '<span class="commerce-zonapagos-pm-info">' . t('(Continue with checkout to complete payment via Zonapagos.)') . '</span>',
    );
  }

  return $form;
}

/**
 * Implements hook_form_FORM_ID_alter().
 */
function commerce_zonapagos_pm_form_commerce_checkout_form_alter(&$form, &$form_state) {
  // If this checkout form contains the payment method radios...
  if (!empty($form['commerce_payment']['payment_method']['#options'])) {
    // Loop over its options array looking for a Zonapagos PM option.
    foreach ($form['commerce_payment']['payment_method']['#options'] as $key => &$value) {
      list($method_id, $rule_name) = explode('|', $key);

      // If we find Zonapagos PM...
      if ($method_id == 'zonapagos_pm') {
        // Prepare the replacement radio button text with icons.
        $icons = commerce_zonapagos_icons();
        $value = t('!logo Zonapagos - Pague seguro sin compartir su información financiera.', array('!logo' => $icons['zonapagos']));
        $value .= '<div class="commerce-zonapagos-icons"><span class="label"></span></div>';
        
        // Add the CSS.
        $form['commerce_payment']['payment_method']['#attached']['css'][] = drupal_get_path('module', 'commerce_zonapagos_pm') . '/theme/commerce_zonapagos_pm.theme.css';

        break;
      }
    }
  }
}

/**
 * Payment method callback: redirect form, a wrapper around the module's general
 *   use function for building a PM form.
 */
function commerce_zonapagos_pm_redirect_form($form, &$form_state, $order, $payment_method) {
  $result = db_query_range('SELECT o.order_number FROM {commerce_order} o WHERE o.status = :status AND o.uid = :uid' ,0,20,
                          array(':status' => 'Pending',':uid' => $order->uid))->fetchField();
   
  if ($result) {
    commerce_payment_redirect_pane_previous_page($order);
    return array();
  }
  
  if (check_order($order,$payment_method['settings']['store_code'],$payment_method['settings']['password']) != '') {
    commerce_payment_redirect_pane_previous_page($order);
    return array();
  }
  // Return an error if the enabling action's settings haven't been configured.
  if (empty($payment_method['settings']['path'])) {
    drupal_set_message(t('Zonapagos PM no está configurado. No se ha especificado la ruta del comercio.'), 'error');
    return array();
  }
  $order = commerce_order_status_update($order, 'Pending');
  $settings = array(
    // Return to the previous page when payment is canceled
    'cancel_return' => url('checkout/' . $order->order_id . '/payment/back/' . $order->data['payment_redirect_key'], array('absolute' => TRUE)),

    // Return to the payment redirect page for processing successful payments
    'return' => url('checkout/' . $order->order_id . '/payment/return/' . $order->data['payment_redirect_key'], array('absolute' => TRUE)),

    // Specify the current payment method instance ID in the notify_url
    'payment_method' => $payment_method['instance_id'],

    // Include the application indicator
    'bn' => $payment_method['buttonsource'],
  );

  return commerce_zonapagos_pm_order_form($form, $form_state, $order, $payment_method['settings'] + $settings);
}

/**
 * Payment method callback: redirect form return validation.
 */
function commerce_zonapagos_pm_redirect_form_validate($order, $payment_method) {
  if (!empty($payment_method['settings']['ipn_logging']) &&
    $payment_method['settings']['ipn_logging'] == 'full_ipn') {
    watchdog('commerce_zonapagos_pm', 'Customer returned from Zonapagos with the following POST data:!ipn_data', array('!ipn_data' => '<pre>' . check_plain(print_r($_POST, TRUE)) . '</pre>'), WATCHDOG_NOTICE);
  }

  // This may be an unnecessary step, but if for some reason the user does end
  // up returning at the success URL with a Failed payment, go back.
  if (!empty($_POST['payment_status']) && $_POST['payment_status'] == 'Failed') {
    return FALSE;
  }
}

/**
 * Payment method callback: validate an IPN based on receiver e-mail address,
 *   price, and other parameters as possible.
 */
function commerce_zonapagos_pm_zonapagos_ipn_validate($order, $payment_method, $ipn) {
  // Prepare a trimmed list of receiver e-mail addresses.
  if (!empty($payment_method['settings']['receiver_emails'])) {
    $receiver_emails = explode(',', $payment_method['settings']['receiver_emails']);
  }
  else {
    $receiver_emails = array();
  }

  // Add the business e-mail address to the list of addresses.
  $receiver_emails[] = $payment_method['settings']['business'];

  foreach ($receiver_emails as $key => &$email) {
    $email = trim(strtolower($email));
  }

  // Return FALSE if the receiver e-mail does not match one specified by the
  // payment method instance.
  if (!in_array(trim(strtolower($ipn['receiver_email'])), $receiver_emails)) {
    commerce_payment_redirect_pane_previous_page($order);
    watchdog('commerce_zonapagos_pm', 'IPN rejected: invalid receiver e-mail specified (@receiver_email); must match the primary e-mail address on the Zonapagos account.', array('@receiver_email' => $ipn['receiver_email']), WATCHDOG_NOTICE);
    return FALSE;
  }

  // Prepare the IPN data for inclusion in the watchdog message if enabled.
  $ipn_data = '';

  if (!empty($payment_method['settings']['ipn_logging']) &&
    $payment_method['settings']['ipn_logging'] == 'full_ipn') {
    $ipn_data = '<pre>' . check_plain(print_r($ipn, TRUE)) . '</pre>';
  }

  // Log a message including the Zonapagos transaction ID if available.
  if (!empty($ipn['txn_id'])) {
    watchdog('commerce_zonapagos_pm', 'IPN validated for Order @order_number with ID @txn_id.!ipn_data', array('@order_number' => $order->order_number, '@txn_id' => $ipn['txn_id'], '!ipn_data' => $ipn_data), WATCHDOG_NOTICE);
  }
  else {
    watchdog('commerce_zonapagos_pm', 'IPN validated for Order @order_number.!ipn_data', array('@order_number' => $order->order_number, '!ipn_data' => $ipn_data), WATCHDOG_NOTICE);
  }
}

/**
 * Payment method callback: process an IPN once it's been validated.
 */
function commerce_zonapagos_pm_zonapagos_ipn_process($order, $payment_method, &$ipn) {
  // Do not perform any processing on PM transactions here that do not have
  // transaction IDs, indicating they are non-payment IPNs such as those used
  // for subscription signup requests.
  if (empty($ipn['txn_id'])) {
    return FALSE;
  }

  // Exit when we don't get a payment status we recognize.
  if (!in_array($ipn['payment_status'], array('Failed', 'Voided', 'Pending', 'Completed', 'Refunded'))) {
    commerce_payment_redirect_pane_previous_page($order);
    return FALSE;
  }

  // If this is a prior authorization capture IPN for which we've already
  // created a transaction...
  if (in_array($ipn['payment_status'], array('Voided', 'Completed')) &&
    !empty($ipn['auth_id']) && $auth_ipn = commerce_zonapagos_ipn_load($ipn['auth_id'])) {
    // Load the prior IPN's transaction and update that with the capture values.
    $transaction = commerce_payment_transaction_load($auth_ipn['transaction_id']);
  }
  else {
    // Create a new payment transaction for the order.
    $transaction = commerce_payment_transaction_new('zonapagos_pm', $order->order_id);
    $transaction->instance_id = $payment_method['instance_id'];
  }

  $transaction->remote_id = $ipn['txn_id'];
  $transaction->amount = commerce_currency_decimal_to_amount($ipn['mc_gross'], $ipn['mc_currency']);
  $transaction->currency_code = $ipn['mc_currency'];
  $transaction->payload[REQUEST_TIME . '-ipn'] = $ipn;

  // Set the transaction's statuses based on the IPN's payment_status.
  $transaction->remote_status = $ipn['payment_status'];

  // If we didn't get an approval response code...
  switch ($ipn['payment_status']) {
    case 'Failed':
      $transaction->status = COMMERCE_PAYMENT_STATUS_FAILURE;
      $transaction->message = t("The payment has failed. This happens only if the payment was made from your customer’s bank account.");
      break;

    case 'Voided':
      $transaction->status = COMMERCE_PAYMENT_STATUS_FAILURE;
      $transaction->message = t('The authorization was voided.');
      break;

    case 'Pending':
      $transaction->status = COMMERCE_PAYMENT_STATUS_PENDING;
      $transaction->message = commerce_zonapagos_ipn_pending_reason($ipn['pending_reason']);
      break;

    case 'Completed':
      $transaction->status = COMMERCE_PAYMENT_STATUS_SUCCESS;
      $transaction->message = t('The payment has completed.');
      break;

    case 'Refunded':
      $transaction->status = COMMERCE_PAYMENT_STATUS_SUCCESS;
      $transaction->message = t('Refund for transaction @txn_id', array('@txn_id' => $ipn['parent_txn_id']));
      break;
  }

  // Save the transaction information.
  commerce_payment_transaction_save($transaction);
  $ipn['transaction_id'] = $transaction->transaction_id;

  // Create a billing profile based on the IPN if enabled.
  if (!empty($payment_method['settings']['ipn_create_billing_profile']) && isset($order->commerce_customer_billing)) {
    $order_wrapper = entity_metadata_wrapper('commerce_order', $order);

    // If this order does not have a billing profile yet...
    if ($order_wrapper->commerce_customer_billing->value() === NULL) {
      // Ensure we have the required data in the IPN.
      if (empty($ipn['residence_country']) || empty($ipn['first_name']) || empty($ipn['last_name'])) {
        $data = array_intersect_key($ipn, drupal_map_assoc(array('residence_country', 'first_name', 'last_name')));
        watchdog('commerce_zonapagos_pm', 'A billing profile for Order @order_number could not be created due to insufficient data in the IPN:!data', array('@order_number' => $order->order_number, '!data' => '<pre>'. check_plain(print_r($data, TRUE)) .'</pre>'), WATCHDOG_WARNING);
      }
      else {
        // Create the new profile now.
        $profile = commerce_customer_profile_new('billing', $order->uid);

        // Add the address value.
        $profile_wrapper = entity_metadata_wrapper('commerce_customer_profile', $profile);

        $profile_wrapper->commerce_customer_address = array_merge(addressfield_default_values(), array(
          'country' => $ipn['residence_country'],
          'name_line' => $ipn['first_name'] . ' ' . $ipn['last_name'],
          'first_name' => $ipn['first_name'],
          'last_name' => $ipn['last_name'],
        ));

        // Save the profile, reference it from the order, and save the order.
        $profile_wrapper->save();
        $order_wrapper->commerce_customer_billing = $profile_wrapper;
        $order_wrapper->save();

        watchdog('commerce_zonapagos_pm', 'Billing profile created for Order @order_number containing the first and last names and residence country of the customer based on IPN data.', array('@order_number' => $order->order_number));
      }
    }
  }

  commerce_payment_redirect_pane_next_page($order);
  watchdog('commerce_zonapagos_pm', 'IPN processed for Order @order_number with ID @txn_id.', array('@txn_id' => $ipn['txn_id'], '@order_number' => $order->order_number), WATCHDOG_INFO);
}

/**
 * Builds a Website Payments Standard form from an order object.
 *
 * @param $order
 *   The fully loaded order being paid for.
 * @param $settings
 *   An array of settings used to build out the form, including:
 *   - server: which server to use, either sandbox or live
 *   - business: the Zonapagos e-mail address the payment submits to
 *   - cancel_return: the URL Zonapagos should send the user to on cancellation
 *   - return: the URL Zonapagos should send the user to on successful payment
 *   - currency_code: the Zonapagos currency code to use for this payment if the
 *     total for the order is in a non-Zonapagos supported currency
 *   - language: the Zonapagos language code to use on the payment form
 *   - payment_action: the Zonapagos payment action to use: sale, authorization,
 *     or order
 *   - payment_method: optionally a payment method instance ID to include in the
 *     IPN notify_url
 *
 * @return
 *   A renderable form array.
 */
function commerce_zonapagos_pm_order_form($form, &$form_state, $order, $settings) {
  $wrapper = entity_metadata_wrapper('commerce_order', $order);

  // Determine the currency code to use to actually process the transaction,
  // which will either be the default currency code or the currency code of the
  // order if it's supported by Zonapagos if that option is enabled.
  $currency_code = 'COP';
  $order_currency_code = $wrapper->commerce_order_total->currency_code->value();

  if (!empty($settings['allow_supported_currencies']) && in_array($order_currency_code, array_keys(commerce_zonapagos_currencies('zonapagos_pm')))) {
    $currency_code = $order_currency_code;
  }

  $amount = $wrapper->commerce_order_total->amount->value();

  // Ensure a default value for the payment_method setting.
  $settings += array('payment_method' => '');
  
  // Build the data array that will be translated into hidden form values.
  $data = array(
    // Specify the checkout experience to present to the user.
    'cmd' => '_cart',

    // Signify we're passing in a shopping cart from our system.
    'upload' => 1,

    // The store's Zonapagos e-mail address
    //'business' => $message,

    // The path Zonapagos should send the IPN to
    //'notify_url' => commerce_zonapagos_ipn_url($settings['payment_method']),

    // The application generating the API request
    //'bn' => 'CommerceGuys_Cart_PPS',

    // Set the correct character set
    'charset' => 'utf-8',

    // Do not display a comments prompt at Zonapagos
    //'no_note' => 1,

    // Do not display a shipping address prompt at Zonapagos
    'no_shipping' => 1,

    // Return to the review page when payment is canceled
    'cancel_return' => $settings['cancel_return'],

    // Return to the payment redirect page for processing successful payments
    'return' => $settings['return'],

    // Return to this site with payment data in the POST
    'rm' => 2,

    // The type of payment action Zonapagos should take with this order
    //'paymentaction' => $settings['payment_action'],

    // Set the currency and language codes
    'currency_code' => $currency_code,
    //'lc' => $settings['language'],

    // Use the timestamp to generate a unique invoice number
    'invoice' => commerce_zonapagos_ipn_invoice($order),

    // Define a single item in the cart representing the whole order
    'amount_1' => commerce_zonapagos_price_amount(commerce_currency_convert($amount, $order_currency_code, $currency_code), $currency_code),
    'item_name_1' => t('Order @order_number at @store', array('@order_number' => $order->order_number, '@store' => variable_get('site_name', url('<front>', array('absolute' => TRUE))))),
    'on0_1' => t('Product count'),
    'os0_1' => commerce_line_items_quantity($wrapper->commerce_line_items, commerce_product_line_item_types()),
  );

  // Allow modules to alter parameters of the API request.
  drupal_alter('commerce_zonapagos_pm_order_form_data', $data, $order);
  
  $id = get_id($order,$settings);
  $form['#action'] = 'https://www.zonapagos.com/' . $settings['path'] . '/pago.asp?estado_pago=iniciar_pago&identificador=' . $id;

  foreach ($data as $name => $value) {
    if (!empty($value)) {
      $form[$name] = array('#type' => 'hidden', '#value' => $value);
    }
  }
  $form['submit'] = array(
    '#type' => 'submit',
    '#value' => t('Registrar pago'),
  );

  return $form;
}

function get_id($order,$settings) {
            $support_phone = $settings['support_phone'];
            $support_email = $settings['support_email'];
            $number = $order->order_number;
            $id_tienda = $settings['store_code'];
            $clave = $settings['password'];
            $res_pagos_v3 = (array) null;
            $int_error = 0;
            $str_error = '';
            $parame = array('str_id_pago' => $number, 'int_id_tienda' => $id_tienda, 'str_id_clave' => $clave, 'res_pagos_v3' => $res_pagos_v3, 'int_error' => $int_error, 'str_error' => $str_error);
            $cliente = new soapclient("http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl");
            $res_pagos_v3 = (array) $cliente->verificar_pago_v3($parame);
            if ($res_pagos_v3['verificar_pago_v3Result'] > 0) {
                $resultp = (array) $res_pagos_v3['res_pagos_v3'];
                $resultp = (array) $resultp['pagos_v3'];
                $cus = (int) $resultp['str_codigo_transaccion'];
                $resultp = $resultp['int_estado_pago'];
                if ($resultp == 999) {
                    $estado = false;
                } else {
                    $estado = true;
                }
            } else {
                $estado = true;
            }
            if ($estado) {
                $total_con_iva = $order->commerce_order_total['und'][0]['amount']/100;
                $valor_iva = $order->commerce_order_total['und'][0]['data']['components'][1]['price']['amount']/100;
                $id_pago =$order->order_number;
                $descripcion_pago = 'Pago de orden: ' . $id_pago;
                $email = $order->mail;
                $id_cliente = $order->uid;
                $tipo_id = 7;
                $nombre_cliente = db_query_range('SELECT ca.commerce_customer_address_first_name FROM {field_revision_commerce_customer_address} ca WHERE ca.entity_id = :entity_id',0,20,
                          array(':entity_id' => $id_pago))->fetchField();
                $apellido_cliente = db_query_range('SELECT ca.commerce_customer_address_last_name FROM {field_revision_commerce_customer_address} ca WHERE ca.entity_id = :entity_id',0,20,
                          array(':entity_id' => $id_pago))->fetchField();
                $telefono_cliente = '';
                $info_opcional1 = '';
                $info_opcional2 = '';
                $info_opcional3 = '';
                $codigo_servicio_principal = $settings['master_code'];
                $lista_codigos_servicio_multicredito = array();
                $lista_nit_codigos_servicio_multicredito = array();
                $lista_valores_con_iva = array();
                $lista_valores_iva = array();
                $total_codigos_servicio = 0;
                $parameters = array('id_tienda' => $id_tienda, 'clave' => $clave, 'total_con_iva' => $total_con_iva, 'valor_iva' => $valor_iva, 'id_pago' => $id_pago, 'descripcion_pago' => $descripcion_pago, 'email' => $email, 'id_cliente' => $id_cliente,
                    'tipo_id' => $tipo_id, 'nombre_cliente' => $nombre_cliente, 'apellido_cliente' => $apellido_cliente, 'telefono_cliente' => $telefono_cliente, 'info_opcional1' => $info_opcional1, 'info_opcional2' => $info_opcional2,
                    'info_opcional3' => $info_opcional3, 'codigo_servicio_principal' => $codigo_servicio_principal, 'lista_codigos_servicio_multicredito' => $lista_codigos_servicio_multicredito,
                    'lista_nit_codigos_servicio_multicredito' => $lista_nit_codigos_servicio_multicredito, 'lista_valores_con_iva' => $lista_valores_con_iva, 'lista_valores_iva' => $lista_valores_iva, 'total_codigos_servicio' => $total_codigos_servicio);
                $client = new SoapClient("http://www.zonapagos.com/ws_inicio_pagov2/Zpagos.asmx?wsdl");
                $result = $client->inicio_pagoV2($parameters);
                $result = $result->inicio_pagoV2Result;
                return $result;
            } else {
                return '';
            }
}

function check_order($order,$id_tienda,$clave) {
            $number = $order->order_number;
            $res_pagos_v3 = (array) null;
            $int_error = 0;
            $str_error = '';
            $cus = '';
            $parame = array('str_id_pago' => $number, 'int_id_tienda' => $id_tienda, 'str_id_clave' => $clave, 'res_pagos_v3' => $res_pagos_v3, 'int_error' => $int_error, 'str_error' => $str_error);
            $cliente = new soapclient("http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl");
            $res_pagos_v3 = (array) $cliente->verificar_pago_v3($parame);
            if ($res_pagos_v3['verificar_pago_v3Result'] > 0) {
                $resultp = (array) $res_pagos_v3['res_pagos_v3'];
                $resultp = (array) $resultp['pagos_v3'];
                $cus = (int) $resultp['str_codigo_transaccion'];
                $resultp = $resultp['int_estado_pago'];
                if ($resultp == 999) {
                    $estado = false;
                } else {
                    $estado = true;
                }
            } else {
                $estado = true;
            }
            if ($estado) {
                return '';
            } else {
                return $cus;
            }
}

/**
 * Returns the URL to the specified Zonapagos PM server.
 *
 * @param $server
 *   Either sandbox or live indicating which server to get the URL for.
 *
 * @return
 *   The URL to use to submit requests to the Zonapagos PM server.
 */
function commerce_zonapagos_pm_server_url($server) {
  switch ($server) {
    case 'sandbox':
      return 'https://www.zonapagos.com';
    case 'live':
      return 'https://www.zonapagos.com';
  }
}

/**
 * Returns an array of all possible language codes.
 */
function commerce_zonapagos_pm_languages() {
  return array(
    t('By country') => array(
      'AU' => t('Australia'),
      'AT' => t('Austria'),
      'BE' => t('Belgium'),
      'BR' => t('Brazil'),
      'CA' => t('Canada'),
      'CN' => t('China'),
      'CO' => t('Colombia'),
      'FR' => t('France'),
      'DE' => t('Germany'),
      'IT' => t('Italy'),
      'NL' => t('Netherlands'),
      'PL' => t('Poland'),
      'PT' => t('Portugal'),
      'RU' => t('Russia'),
      'ES' => t('Spain'),
      'CH' => t('Switzerland'),
      'GB' => t('United Kingdom'),
      'US' => t('United States'),
    ),
    t('By language') => array(
      'da_DK' => t('Danish (for Denmark only)'),
      'he_IL' => t('Hebrew (for all)'),
      'id_ID' => t('Indonesian (for Indonesia only)'),
      'jp_JP' => t('Japanese (for Japan only)'),
      'no_NO' => t('Norwegian (for Norway only)'),
      'pt_BR' => t('Brazilian Portuguese (for Portugal and Brazil only)'),
      'ru_RU' => t('Russian (for Lithuania, Latvia, and Ukraine only)'),
      'sv_SE' => t('Swedish (for Sweden only)'),
      'th_TH' => t('Thai (for Thailand only)'),
      'tr_TR' => t('Turkish (for Turkey only)'),
      'zh_CN' => t('Simplified Chinese (for China only)'),
      'zh_HK' => t('Traditional Chinese (for Hong Kong only)'),
      'zh_TW' => t('Traditional Chinese (for Taiwan only)'),
    ),
  );
}
