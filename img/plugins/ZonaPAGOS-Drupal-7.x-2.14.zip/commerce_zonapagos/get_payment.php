<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
chdir('../../../../');
define('DRUPAL_ROOT', getcwd());
require_once (getcwd() . '/includes/bootstrap.inc');
require_once ('modules/pm/libraries/nusoap/nusoap.php');
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL); 

$rule = rules_config_load('commerce_payment_zonapagos_pm');
foreach ($rule->actions() as $action) {
  $settings[] = $action->settings[payment_method][settings];
}

$id_pago = $_GET['id_pago'];
$id_tienda = $settings[0]['store_code'];
$clave_tienda = $settings[0]['password'];
$order = commerce_order_load($id_pago);

$client = new nusoap_client('http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl', 'wsdl', '', '', '','');
$params = array_merge( array (
   		'str_id_pago' => $id_pago,
    		'int_id_tienda' => $id_tienda,
    		'str_id_clave' => $clave_tienda)
) ;
		
$resultp = $client->call('verificar_pago_v3', $params);
$result = $resultp['verificar_pago_v3Result'];
	
if ($result == '1' ){
	$estado_pago = $resultp['res_pagos_v3']['pagos_v3']['int_estado_pago'];
	if ($estado_pago == '1'){		
		$order = commerce_order_status_update($order, 'completed');
		commerce_order_save($order);
		rules_invoke_all(COMMERCE_PAYMENT_STATUS_SUCCESS, $order);
	}
} else {
	$order = commerce_order_status_update($order, 'canceled');
	commerce_order_save($order);
	rules_invoke_all(COMMERCE_PAYMENT_STATUS_FAILURE, $order);
}
?>
