<?php 
	$id_pago = $_GET['id_pago'];
	$id_tienda = '1234';
	$clave_tienda = 'clave';
	$dbhost = 'localhost';	
	$dbuser = 'user';	
	$dbpass = 'password';
	$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	$dbname = 'nombredb';
	$dbprefix = 'prefijo';
	mysql_select_db($dbname);

	require_once('libraries/nusoap/nusoap.php');
	$client = new nusoap_client('http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl', 'wsdl', '', '', '','');
				
	$params = array_merge( array (
    		'str_id_pago' => $id_pago,
    		'int_id_tienda' => $id_tienda,
    		'str_id_clave' => $clave_tienda)
    	) ;
		
	$resultp = $client->call('verificar_pago_v3', $params);
	$result = $resultp['verificar_pago_v3Result'];
	
	if ($result == '1' ){
		$estado_pago = $resultp['res_pagos_v3']['pagos_v3']['int_estado_pago'];
		if ($estado_pago == '1'){		
			$sql = "UPDATE `" . $dbprefix . "_virtuemart_orders` SET `order_status`= 'C' WHERE `virtuemart_order_id` = " . $id_pago;
			mysql_query($sql) or die('Error, insert query failed 2');
		}
		mysql_close($conn);
		
	} else {
		$sql = "UPDATE `" . $dbprefix . "_virtuemart_orders` SET `order_status`= 'X' WHERE `virtuemart_order_id` = " . $id_pago;
		mysql_query($sql) or die('Error, insert query failed 1 '.$sql);
		mysql_close($conn);
	}
?>
