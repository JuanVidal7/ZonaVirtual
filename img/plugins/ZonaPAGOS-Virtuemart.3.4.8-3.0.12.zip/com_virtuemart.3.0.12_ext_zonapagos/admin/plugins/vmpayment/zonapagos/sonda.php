<?php
	date_default_timezone_set("America/Bogota");
	$id_tienda = '1234';
	$clave_tienda = 'clave';
	$dbhost = 'localhost';	
	$dbuser = 'user';	
	$dbpass = 'password';
	$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die ('Error connecting to mysql');
	$dbname = 'nombredb';
	$dbprefix = 'prefijo';
	mysql_select_db($dbname);
	$now = date('Y-m-d H:i:s');
	
	$sql = "SELECT `virtuemart_order_id` FROM `" . $dbprefix . "_virtuemart_orders` WHERE `order_status` = 'P' AND ('" . $now . "' > DATE_ADD( `modified_on`, INTERVAL 7 MINUTE)) AND virtuemart_paymentmethod_id = (SELECT `virtuemart_paymentmethod_id` FROM `" . $dbprefix . "_virtuemart_paymentmethods` WHERE `payment_element` = 'zonapagos')";
		
	$result = mysql_query($sql) or die('Error, insert query failed 2');
	
	while ($resultc = mysql_fetch_array($result)){
		$order_id = $resultc['virtuemart_order_id'];
		require_once('libraries/nusoap/nusoap.php');
		$client = new nusoap_client('http://www.zonapagos.com/ws_verificar_pagos/Service.asmx?wsdl', 'wsdl', '', '', '','');	
		$params = array_merge( array (    		
					'str_id_pago' => $order_id,
					'int_id_tienda' => $id_tienda,
					'str_id_clave' => $clave_tienda)
					) ;
		$resultp = $client->call('verificar_pago_v3', $params);
		//print_r($resultp);
		if($resultp['int_error'] == "0"){
			$resultp_est = (int)$resultp['res_pagos_v3']['pagos_v3']['int_estado_pago'];
			if($resultp_est == '1' ){
				$sql2 = "UPDATE `" . $dbprefix . "_virtuemart_orders` SET `order_status`= 'C' WHERE `virtuemart_order_id` = " . $order_id;
				mysql_query($sql2) or die('Error, insert query failed 3');
				} 	
		} else {
			$sql2 = "UPDATE `" . $dbprefix . "_virtuemart_orders` SET `order_status`= 'X' WHERE `virtuemart_order_id` = " . $order_id;
			mysql_query($sql2) or die('Error, insert query failed 5');
		}			
	}
	
	mysql_close($conn);
?>
